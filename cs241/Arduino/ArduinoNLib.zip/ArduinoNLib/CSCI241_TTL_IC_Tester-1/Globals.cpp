// Global variables for TTL IC Tester program

// Each IC test routine should set this global to the number of pins on the
// IC being tested.

int NumICPins = 0;
