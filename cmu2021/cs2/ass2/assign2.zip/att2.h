#include <iostream> 
using namespace std;
#include <fstream>

class Node
{
    public:
    int number;
    char data;
    int serviceTime = 0;//how long they've actually stayed in line
    int customerID = 0;
    int arrivalTime = 0;
    int transactionTime = 0;//when 30s, dequeue
    int hasArrived = -1;
    Node * next;
    int end = 0;
    
    Node()
    {
        number = 0;
        data = ' ';
    }
    Node(int n,char d)
    {
        transactionTime = n;
        data = d;
        //arrivalTime = a;
        next = NULL;
    }
};
class Queue
{
    public:
    Node *cheque;
    Node *front;
    Node *rear;
    Queue()
    {
        front = NULL;
        rear = NULL;
    }
    bool isEmpty()
    {
        Node *listptr = front;
        //front = listptr;
        bool isEmpty = true;
        while(listptr!=NULL)//if line is NOT empty
        {
            
            if(listptr->hasArrived = 1)//returning false that the line is NOT empty
            {
                isEmpty = true;
            }
            
            listptr = listptr->next;
        
        }
        return isEmpty;
    }
    bool checkIfNodeExists(Node *n)
    {
        Node *temp = front;
        bool exist = false;
        while(temp!=NULL)
        {
            if(temp->transactionTime==n->transactionTime)
            {
                exist = true;
                break;
            }
            return exist;
        }
    }
    bool isLinkedListEmpty()
    {
        if(front == NULL && rear == NULL)
        {
            return false;//if line is empty return false
        }
        else
            return true;
    }
    void enqueue(int parrivalTime, int ptransactionTime,char pdata,int pserviceTime,int phasArrived, int pcustomerID)
    {
        //create a new node
        //pass all the data
        //connect the nodes
        Node *node = new Node;

        node->arrivalTime = parrivalTime;
        node->transactionTime = ptransactionTime;
        node->data=pdata;
        node->customerID = pcustomerID;
        node->serviceTime=pserviceTime;
        node->hasArrived=phasArrived;

        if(front == NULL)
        {
            front = node;  
            rear = node;    
            front->next = NULL;
            rear->next = NULL;
        }
        else//not our first node, we need to add it to the back of the list
        {
            rear->next = node;
            rear = node;
            rear->next = NULL;
        }
        //see what is in the rear node via the rear pointer HERE
        //cout << " arrival time " <<rear->arrivalTime<< endl;
    }
    void readFile()
    {
        //Queue q;
        int transactionTime = 0;
        char data = ' ';
        const int hasArrived = -1;
        int serviceTime = 0;
        int lines = 50;
        int customerID = 0;
        int arrivalTime = 0;
        ifstream inD;
        inD.open("Ass2.dat");
        
        for(int i = 0; i < lines; i++)//change to a controlled loop (eof)
        {
            inD >> arrivalTime;
            // inD >> ws;
            // inD >> ws;
            // inD >> ws;
            inD >> data;
            customerID++; 
            enqueue(arrivalTime,transactionTime,data,serviceTime,hasArrived,customerID);
            
        }
    }
    void display()
    {
        Node* curr;
        curr = front;

        while (curr != nullptr)
        {
            cout << curr->arrivalTime << " " << curr->data << "  " << curr->customerID << endl;
            curr = curr->next;
        }
        cout << endl;
    }

    void dequeue(Node *&point)
    {
        if(point == NULL)//if front is empty
        {
            rear = NULL;//clear rear
            
            return;//supposed to be when the line is empty
        }
        //#problem here too
        cout << "customer #: " << point->customerID << "is leaving  the line " << endl;

        if (point->next == NULL)//if next node is empty
        {
            cout << "123123" << endl;
            point->transactionTime = 100;
            point->hasArrived = -1;
            return;
        }

        point = point -> next;
        point->hasArrived = -1;
        point->transactionTime = 0;
        //add 30 to their arrival time to go back into the clockcounter while loop
        //right????
        //to put them back in the normal line
        
        //point->arrivalTime += 30;
        
        
        //delete(temp);//delete temp
    }
    void moveLineDQ(Node *&point)
    {
            cout <<"1!:" << point->transactionTime << endl;
            Node * newnode = front;
            int truecount = 0;
            if(point->transactionTime == 30)//#PROBLEM HEREEEEE
            {
                cout << "test" <<endl;
                cout << point->hasArrived << "has arrived" << endl;
                dequeue(point);
            }
   
    }
    void checkFront()
    {
    //create a ptr that poitns to head
    //Node * temp
    //check if ptr is null
    //if so, line IS empty
    //check if hasArrived() = true only if ptr != null
    //if so, cout << "there is someone in line" << endl
    Node * temp = front;
    //cout << "has arrived = " << temp->hasArrived << " "<<endl;
    if(front!=NULL)
    {
        if(temp->hasArrived == -1)
        {
            cout << "the line is empty" << endl;
        }
        else if(temp->hasArrived == 1)
        {
            //cout << "the line is NOT empty" << endl;
        }
    }
    }

    void addToQueue(int clockCounter, Node *&point)
    {
        Node * pointer = front;
    
        while(pointer->next != NULL && pointer->next->arrivalTime <= clockCounter)
        {
            pointer = pointer->next;
        }
        if(pointer != front)
        {
        front->next = pointer->next;//here
        pointer->next = front;

        front->transactionTime = 1;
        front->data = '$';
        point = point->next;
        //set front transact
        }
        else
        {
            point->transactionTime = 0;
            point->data = '$';
        }
        cout<< "front->next->customerID " << front->next->customerID << endl;

    }

    void inLine()
    {
        int clockCounter = 0;
        int serviceTime = 0;
        //int customerID = 0;
        Node *ptr = front;
        Node *point = front;

        //implement
        //create another linked list called cheque (...?)
        //have it's own "queue" of people that will send to the end of the normal cash line
        //possibly have to change customer's arrival time after

        //while(clockCounter < 1500)
        {
            //if(point->arrivalTime == clockCounter)
            {
                //point->front = cheque->front;
                //dequeue();
                //point->front = front;
            }
            //if(   )
        }
        while(clockCounter < 1500)//clock timer to iterate
        {
            cout << clockCounter << ":clock" << endl;
            checkFront();
            //cout << "clockcounter: " << clockCounter << endl;
            //cout << "arrival time: " << ptr->arrivalTime << endl;
            if(point->arrivalTime == clockCounter)
            {
                point->hasArrived = 1;
                
                cout << "customer #: " << point->customerID << "has arrived now. "<<endl;
                
                point->transactionTime=1;
                
                if(point->next!=NULL)
                {
                    ptr = ptr->next;
                }
                else
                {
                    ptr->hasArrived = -1;
                }
            }
            else if(point->arrivalTime < clockCounter && point->transactionTime == 0)//to catch the one lacking behind
            {//to catch the difference in line
                cout << "transaction time" << point->transactionTime << endl;
                cout << "here test 123" << endl;
                point->hasArrived = 1;
                point->transactionTime = 1;
                if(point->next != NULL)
                {
                    ptr = ptr->next;
                }
                else
                {
                    ptr->hasArrived = -1;
                }
            }
            
            else if(point->data == 'C' && point->transactionTime == 10)//need to account for credit card difference +10s.
            {
                //check if cheque
                //if cheque, move to back of line
                addToQueue(clockCounter, point);

                cout << "customer id: " << point->customerID <<endl;
            }
            //Trying to use moveLineDQ() to grab their transaction time, and dequeue them from the line
            //
            moveLineDQ(point);
            if(point->hasArrived = -1 && point->transactionTime >= 100)//make a side variable to check against for last person MAKE AN INDICATOR
            {//this is stopping at customerID: 49 right now, it needs to go to 50
                cout <<  "the line is empty now!" <<endl;
                break;
            }
            if(point->transactionTime > 0)
            {
                point->transactionTime++;
                cout << endl << clockCounter <<" : Customer # "<<point->customerID
                << "is currently being served."<< endl;
            }

            else
            {
                cout << endl;
            }
            clockCounter++;
        }
        //ptr->customerID++;
    }
};
