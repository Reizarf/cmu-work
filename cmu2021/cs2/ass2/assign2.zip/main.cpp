#include <iostream>
#include "att2.h"
//using namespace std;
int main()
{
    Queue q;
    int option, transactionTime = 0;
    char data = ' ';
    int a = 0;

    Node * new_node = new Node();
    //n = new_node;

    q.readFile();
    for(int k = 0; k < 1; k++)
    {
        cout <<endl <<  "Press an option." << endl;
        cin >> option;
        
        // if(option == 1)
        // {
        //     cout << "readfile func" << endl;
        //     q.readFile();
        // }
        if(option == 1)
        {
            cout <<"inline" << endl;
            q.inLine();
            //q.enqueue(parrivalTime,ptransactionTime,pdata,pserviceTime,phasArrived,pcustomerID);
        
        }
        if(option == 2)//display
        {
            cout << "display option chosen: " <<endl;
            q.display();
        }
        
    }

    a++;
}


