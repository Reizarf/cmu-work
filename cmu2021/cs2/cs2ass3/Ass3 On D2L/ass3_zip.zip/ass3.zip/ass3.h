/**********************************************************************
 * ass3.h - CSCI112 - Ass3 - Header file for text file word statistics program
 * <Sullivan Frazier> <STUDENT No.> <DATE>
 **********************************************************************/
#ifndef ASS3_H
#define ASS3_H

void TestContainers();
void ReadTxtFile();
void DisplayWordStats();
void WriteTxtFile();
void CleanUp();

#endif
