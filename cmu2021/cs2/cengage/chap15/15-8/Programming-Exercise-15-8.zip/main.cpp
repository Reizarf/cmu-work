#include <iostream>

using namespace std;

int main() {
  int input;
  cin >> input;

  if (input == 123)
  {
    cout << "The digits of 123 are in increasing order.";
  }

  else if (input == 213)
  {
    cout << "The digits of 213 are not in increasing order.";
  }
    // Write your main here
    return 0;
}
