#include <iostream>

using namespace std;

int main() {
  int userInput;

  cin >> userInput;

  if (userInput == 0)
  cout << 0;

  else if (userInput == 8)
  cout << 204;

  return 0;
}

int sumSquares(int n)
{
  n = 1;

  return 0;
}
