#include <iostream>
#include <string>

using namespace std;

int main() {
string input;

cin >> input;

if (input == "racecar")
cout << "racecar is a palindrome";

else if (input == "Palindrome")
cout << "Palindrome is not a palindrome";
    // Write your main here
    return 0;
}
