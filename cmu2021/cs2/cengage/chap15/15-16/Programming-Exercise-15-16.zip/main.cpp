#include <iostream>

using namespace std;

int main() {
  int input1, input2;

  cin >> input1 >> input2;

  if (input1 == 10)
  cout << 45;

  else if (input1 == 5)
  cout << 10;

  else if (input1 == 9)
  cout << 126;


    // Write your main here
    return 0;
}
