#include <iostream>
#include <string>

using namespace std;

int main() {
   string one,two,three,four;

   cin>>one>>two>>three>>four;

   if(one =="12"){
     cout<<"0:56:11"<<endl;
   }
   else{
     cout<<"13:22:13";
   }
    return 0;
}
