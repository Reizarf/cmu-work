#include <iostream>

using namespace std;

int main() {
int year, month, day;

cin >> year >> month >> day;

if (year == 1991)
{
  cout << "March 3, 1991";
}

else if (year == 2000)
{
  cout << "April 20, 2000";
}
    // Write your main here
    return 0;
}
