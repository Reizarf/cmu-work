 
//Data:  18 42 78 22 42 5 42 57 
 
#include <iostream>

using namespace std;

int main() {
    // Write your main here
    return 0;
}
