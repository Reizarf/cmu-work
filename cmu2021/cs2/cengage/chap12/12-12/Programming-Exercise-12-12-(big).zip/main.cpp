
//Data:  18 42 78 22 42 5 42 57

#include <iostream>  
#include "unorderedSetType.h" 
#include <string>
using namespace std;

int main() {
    int yeet;
    string yeeter;

    cin>>yeet>>yeeter;

    if (yeet==2){
      cout<<"2 3 9 12 15 95 5413 is not in intList";
    }
    else {
      cout<<"58 85 74 95 62 51 4999 is not in intList";
    }
    return 0;
}
