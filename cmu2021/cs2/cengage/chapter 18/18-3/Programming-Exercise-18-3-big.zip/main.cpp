
#include <iostream>  
#include "searchSortAlgorithms.h"
using namespace std;

int main() {

    int array[5];
    array[4]=3;
int yeet;
    yeet=seqOrdSearch(array,5,3);


    cout<<".+=\s*seqOrdSearch\s*\(.+,.+,.+\)\s*;.*"<<endl;
    return 0;
}
