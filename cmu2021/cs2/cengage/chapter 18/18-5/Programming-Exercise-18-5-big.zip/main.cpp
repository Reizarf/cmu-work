
#include <iostream>
#include "searchSortAlgorithms.h"

using namespace std;

int main() {

    int array[5];

    modifiedBubbleSort(array,5);
    return 0;
}
