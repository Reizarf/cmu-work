#include <iostream>

using namespace std;




template <class T>

void modifiedBubbleSort(T list[], int length){

for(int i = 0; i < length - 1; i++){

    for(int j = 0; j < length - i - 1; j++){

      if(list[j] > list[j+1]){

        T temp = list[j];

        list[j] = list[j+1];

        list[j+1] = temp;

      }

    }

    for(int j = 0; j < length; j++)

      cout << list[j] << " ";

    cout << endl;

}

}

