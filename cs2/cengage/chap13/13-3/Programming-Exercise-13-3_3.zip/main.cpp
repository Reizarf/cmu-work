#include <iostream>

using namespace std;

int main() {
    // Write your main here
    return 0;
}
