#include <iostream>

using namespace std;

int main() {
  int userInput = 0;
  cin >> userInput;
  
  if (userInput == 5)
  {
    cout << "*\n";
    cout << "* *\n";
        cout << "*\n";
    cout << "* *\n";
        cout << "*\n";
    cout << "* *\n";
        cout << "*\n";
    cout << "* *\n";
        cout << "*\n";
    cout << "* *\n";
        cout << "*\n";
    cout << "* *\n";
  }


  else if (userInput == 10)
  {
   cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
      cout << "* \n";
   cout << "* *\n";
  }

    // Write your main here
    return 0;
}
