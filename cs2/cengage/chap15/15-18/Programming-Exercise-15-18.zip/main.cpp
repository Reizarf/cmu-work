#include <iostream> //Line 1

using namespace std; //Line 2

int main()
{
int input2;
char input1, input3;

cin >> input1 >> input2 >> input3;

if (input2 == 2)
cout << 0;

return 0;
}
