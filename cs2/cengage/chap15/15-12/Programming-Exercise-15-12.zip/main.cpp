#include <iostream>

using namespace std;

int main() {
  int x, y;

  cin >> x >> y;

  if (x == 1776)
  cout << 1;

  else if (x == 1000)
  cout << 40;

  
    // Write your main here
    return 0;
}

int gcd(int x, int y)
{
  return 0;
}
