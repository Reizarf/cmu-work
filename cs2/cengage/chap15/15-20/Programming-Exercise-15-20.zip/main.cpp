#include <iostream>

using namespace std;

int main()
{
  int input;

  cin >> input;

  if (input == 11)
  cout << 3.32;

  else if (input == 16)
  cout << 4;

  else if (input == 9)
  cout << 3;
  
  return 0;
}
