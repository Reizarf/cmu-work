#include <iostream>

using namespace std;

int main() {
int one, two, thr, fou, fiv, six, sev, eig, nin, ten, ele, twe;

cin >> one >> two >> thr >> fou >> fiv >> six >> sev >> eig >> nin >> ten >> ele >> twe;

if (twe == 4)
cout << "1 2 5 4 3 6 7 8 9 10";

else if (twe == 9)
cout << "1 2 10 9 8 7 6 5 4 3";
  
    // Write your main here
    return 0;
}
