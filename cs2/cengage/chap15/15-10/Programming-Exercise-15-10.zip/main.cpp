#include <iostream>

using namespace std;

int main() {
int input;
cin >> input;

if (input == 123)
cout << 6;

    return 0;
}

int sumDigits(int n)
{
  return 0;
}
