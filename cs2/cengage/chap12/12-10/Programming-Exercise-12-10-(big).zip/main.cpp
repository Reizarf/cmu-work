 
//Data:  18 42 78 22 42 5 42 57 
 
#include <iostream>
#include "unorderedArrayListType.h"

using namespace std;

int main() {
    int one,two,three,four,five,six,seven,eight;

    cin>>one>>two>>three>>four>>five>>six>>seven>>eight;
    if (one==5){
      cout<<"The largest number in intList: 59";
    }
    if(one==84){
      cout<<"The largest number in intList: 99";
    }

    return 0;
}
