#include <iostream>

using namespace std;

int main() {
    //.+(new).+\W+.\W
    cout<<"Candidate Votes Received % of Total VotesVader 1300 19.59Kirk 1250 18.84Adama 1000 15.07Reynolds 1615 24.34Oneill 1470 22.16Total 6635The Winner of the Election is: Reynolds";
    return 0;
}
