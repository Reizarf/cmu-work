/*
	This file contains the implementation for class file.

	Sherine Antoun
    Colorado Mesa University
*/

#include <iostream>
#include <fstream>
#include "file.h"
using namespace std;

// the default constructor should just initialise the private members to nothing

file::file()
{

}


// initialisation constructor to associate file with class instance
// allocated appropriate segments on the heap.

file::file(char filename[])
{
	
}

// associated method takes a file, seeks to end, allocates memory on heap then copies
// contents into buffer

void file::associate(char filename[])
{
	
}
