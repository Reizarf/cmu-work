/**********************************************************************
 * ass3.cpp - CSCI112 BTree - Implementation file for displaying text file word statistics
 * <NAME> <STUDENT No.> <DATE>
 **********************************************************************/
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cctype>
#include "list.h"
#include "btree.h"
using namespace std;

// ******** Global Data ********

BinaryTree WordTree;

// ******** Function Prototypes ********

void CleanUp();

// ******** Menu Function Definitions ********

void TestContainers()
{
	int i; char *WrdPtr, Word[10];

	cout<<"\n **** TESTING CONTAINERS ****\n";
	cout<<"Testing IntList\n";
	LinkedList IntList;		// declare a list of ints
	cout<<"Inserted:=> ";
	for(i=0;i<10;i++)
	{
		cout<<i<<' ';
		IntList.AddToTail(i);	// insert some ints into it
	}
	cout<<endl;
	IntList.SetIterator();
	cout<<"Extracted=> ";
	while(IntList.More())
		cout<<IntList.Next()<<' ';            // print the ints in the list
	cout<<endl<<endl;
/*
	cout<<"Testing WordTree\n";
	WordCounterPtr P1, P2;                        // declare some WordCounterPtrs
	Word[1]='\0';
	cout<<"Inserted => \n";
	for(i=0;i<100;i++)
	{
		Word[0]='A'+rand()%10;                // get a random 1 letter word
		cout<<Word<<' ';
		P1 = new WordCounterType;             // allocate new  WordCounterType
		P1->Word = new char[strlen(Word)+1];  // allocate memory for each word
		strcpy(P1->Word,Word);
		P1->Count = 1;                        // set word counter
		int WordPos = i;
		P1->LocList.Insert(WordPos);          // add the word's position to the new WordCounter
		if(WordTree.Locate(P1, P2))           // if word is already in tree then...
		{
			P2->Count++;                     // increment esisting WordCounter
			P2->LocList.AddToTail(WordPos);  // add the word's position to the existing WordCounter
			delete P1->Word;                 // get rid of not needed WordCounter
			delete P1;                       // ditto
		}
		else
			WordTree.Insert(P1);             // else not in tree! so insert WordCounter
	}
	cout<<endl;
	cout<<"Extracted=> \n";
	WordTree.SetIterator();
	while(WordTree.More())
	{
		P1 = WordTree.Next();
		cout << P1->Word;                        // print each word in the tree
		cout << '\t' << P1->Count<<"\t";
		P1->LocList.SetIterator();
		while(P1->LocList.More())
			 cout<<P1->LocList.Next()<<' ';
		cout << endl;
	}
	cout<<endl;
	CleanUp();                                      // delete tree
	cout<<" **** END OF TESTS ****\n\n";
*/
}


void ReadTxtFile()
{
// ask user to "Enter filename: ";
// open file
// if file not found then print error msg and exit
// set counter to zero
// read word
// while not eof
//     convert word to lower case and remove any punctuation marks
//     increment counter
//     allocate new WordCounterType
//     put data in new WordCounter
//     if word is already in tree then
//         inc existing WordCounter
//         add the location (ie counter value) to existing WordCounter
//         free memory 
//     else
//         add new wordCounter to tree
//  print how many words were added to tree
//  close file
}


void DisplayWordStats()
{
// set WordTree's Iterator
// print heading
// while more words in tree do
//     get next WordCounterPtr
//     print word
//     print word count 
//     set WordCounter's list iterator
//     while more ints in list
//         print next word location
//
}


void CleanUp()
{
// set WordTree's Iterator
// while more words in tree do
//     get next WordCounterPtr
//     free data
// Kill tree
}

